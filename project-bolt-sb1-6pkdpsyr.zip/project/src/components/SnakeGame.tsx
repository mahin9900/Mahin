import React, { useState, useEffect, useCallback } from 'react';
import { Play, Pause, RotateCcw, Trophy, Gamepad2 } from 'lucide-react';

interface Position {
  x: number;
  y: number;
}

const GRID_SIZE = 20;
const INITIAL_SNAKE = [{ x: 10, y: 10 }];
const INITIAL_FOOD = { x: 15, y: 15 };
const INITIAL_DIRECTION = { x: 0, y: -1 };

const SnakeGame: React.FC = () => {
  const [snake, setSnake] = useState<Position[]>(INITIAL_SNAKE);
  const [food, setFood] = useState<Position>(INITIAL_FOOD);
  const [direction, setDirection] = useState<Position>(INITIAL_DIRECTION);
  const [gameRunning, setGameRunning] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    return parseInt(localStorage.getItem('snakeHighScore') || '0');
  });
  const [gameOver, setGameOver] = useState(false);

  const generateFood = useCallback((): Position => {
    const newFood = {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE),
    };
    return newFood;
  }, []);

  const resetGame = () => {
    setSnake(INITIAL_SNAKE);
    setFood(INITIAL_FOOD);
    setDirection(INITIAL_DIRECTION);
    setGameRunning(false);
    setScore(0);
    setGameOver(false);
  };

  const toggleGame = () => {
    if (gameOver) {
      resetGame();
    } else {
      setGameRunning(!gameRunning);
    }
  };

  const moveSnake = useCallback(() => {
    if (!gameRunning || gameOver) return;

    setSnake(currentSnake => {
      const newSnake = [...currentSnake];
      const head = { ...newSnake[0] };
      
      head.x += direction.x;
      head.y += direction.y;

      // Check wall collision
      if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
        setGameOver(true);
        setGameRunning(false);
        return currentSnake;
      }

      // Check self collision
      if (newSnake.some(segment => segment.x === head.x && segment.y === head.y)) {
        setGameOver(true);
        setGameRunning(false);
        return currentSnake;
      }

      newSnake.unshift(head);

      // Check food collision
      if (head.x === food.x && head.y === food.y) {
        setScore(prev => {
          const newScore = prev + 10;
          if (newScore > highScore) {
            setHighScore(newScore);
            localStorage.setItem('snakeHighScore', newScore.toString());
          }
          return newScore;
        });
        setFood(generateFood());
      } else {
        newSnake.pop();
      }

      return newSnake;
    });
  }, [direction, food, gameRunning, gameOver, generateFood, highScore]);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (!gameRunning) return;

      switch (e.key) {
        case 'ArrowUp':
          if (direction.y !== 1) setDirection({ x: 0, y: -1 });
          break;
        case 'ArrowDown':
          if (direction.y !== -1) setDirection({ x: 0, y: 1 });
          break;
        case 'ArrowLeft':
          if (direction.x !== 1) setDirection({ x: -1, y: 0 });
          break;
        case 'ArrowRight':
          if (direction.x !== -1) setDirection({ x: 1, y: 0 });
          break;
        case ' ':
          e.preventDefault();
          toggleGame();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [direction, gameRunning]);

  useEffect(() => {
    const gameInterval = setInterval(moveSnake, 150);
    return () => clearInterval(gameInterval);
  }, [moveSnake]);

  const handleDirectionChange = (newDirection: Position) => {
    if (!gameRunning) return;
    
    if (
      (newDirection.x !== 0 && direction.x === 0) ||
      (newDirection.y !== 0 && direction.y === 0)
    ) {
      setDirection(newDirection);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-green-400 via-blue-500 to-purple-600 p-4">
      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-2xl w-full">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Gamepad2 className="text-green-600" size={32} />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
              Snake Game
            </h1>
          </div>
          
          {/* Score Display */}
          <div className="flex justify-center gap-8 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-800">{score}</div>
              <div className="text-sm text-gray-600">Score</div>
            </div>
            <div className="text-center">
              <div className="flex items-center gap-1 justify-center">
                <Trophy className="text-yellow-500" size={20} />
                <span className="text-2xl font-bold text-gray-800">{highScore}</span>
              </div>
              <div className="text-sm text-gray-600">Best</div>
            </div>
          </div>
        </div>

        {/* Game Board */}
        <div className="relative mb-6">
          <div 
            className="grid gap-1 bg-gray-800 p-4 rounded-2xl mx-auto"
            style={{
              gridTemplateColumns: `repeat(${GRID_SIZE}, 1fr)`,
              width: '400px',
              height: '400px'
            }}
          >
            {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, index) => {
              const x = index % GRID_SIZE;
              const y = Math.floor(index / GRID_SIZE);
              
              const isSnakeHead = snake[0]?.x === x && snake[0]?.y === y;
              const isSnakeBody = snake.slice(1).some(segment => segment.x === x && segment.y === y);
              const isFood = food.x === x && food.y === y;
              
              return (
                <div
                  key={index}
                  className={`rounded-sm transition-all duration-150 ${
                    isSnakeHead
                      ? 'bg-gradient-to-br from-green-400 to-green-600 shadow-lg'
                      : isSnakeBody
                      ? 'bg-gradient-to-br from-green-300 to-green-500'
                      : isFood
                      ? 'bg-gradient-to-br from-red-400 to-red-600 shadow-lg animate-pulse'
                      : 'bg-gray-700'
                  }`}
                />
              );
            })}
          </div>

          {/* Game Over Overlay */}
          {gameOver && (
            <div className="absolute inset-0 bg-black bg-opacity-75 rounded-2xl flex items-center justify-center">
              <div className="text-center text-white">
                <h2 className="text-3xl font-bold mb-2">Game Over!</h2>
                <p className="text-xl mb-4">Score: {score}</p>
                {score === highScore && score > 0 && (
                  <p className="text-yellow-400 mb-4">🎉 New High Score!</p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="space-y-4">
          {/* Game Buttons */}
          <div className="flex justify-center gap-4">
            <button
              onClick={toggleGame}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-200"
            >
              {gameOver ? (
                <>
                  <RotateCcw size={20} />
                  Play Again
                </>
              ) : gameRunning ? (
                <>
                  <Pause size={20} />
                  Pause
                </>
              ) : (
                <>
                  <Play size={20} />
                  Start
                </>
              )}
            </button>
            
            <button
              onClick={resetGame}
              className="flex items-center gap-2 px-6 py-3 bg-gray-500 text-white rounded-xl font-semibold hover:bg-gray-600 transition-colors duration-200"
            >
              <RotateCcw size={20} />
              Reset
            </button>
          </div>

          {/* Mobile Controls */}
          <div className="grid grid-cols-3 gap-2 max-w-48 mx-auto md:hidden">
            <div></div>
            <button
              onClick={() => handleDirectionChange({ x: 0, y: -1 })}
              className="bg-blue-500 text-white p-3 rounded-lg font-bold hover:bg-blue-600 transition-colors"
            >
              ↑
            </button>
            <div></div>
            <button
              onClick={() => handleDirectionChange({ x: -1, y: 0 })}
              className="bg-blue-500 text-white p-3 rounded-lg font-bold hover:bg-blue-600 transition-colors"
            >
              ←
            </button>
            <div></div>
            <button
              onClick={() => handleDirectionChange({ x: 1, y: 0 })}
              className="bg-blue-500 text-white p-3 rounded-lg font-bold hover:bg-blue-600 transition-colors"
            >
              →
            </button>
            <div></div>
            <button
              onClick={() => handleDirectionChange({ x: 0, y: 1 })}
              className="bg-blue-500 text-white p-3 rounded-lg font-bold hover:bg-blue-600 transition-colors"
            >
              ↓
            </button>
            <div></div>
          </div>

          {/* Instructions */}
          <div className="text-center text-gray-600 text-sm">
            <p className="mb-2">🎮 Use arrow keys to control the snake</p>
            <p className="mb-2">🍎 Eat the red food to grow and score points</p>
            <p>⚠️ Don't hit the walls or yourself!</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SnakeGame;