import React from 'react';
import SnakeGame from './components/SnakeGame';

function App() {
  return <SnakeGame />;
}

export default App;